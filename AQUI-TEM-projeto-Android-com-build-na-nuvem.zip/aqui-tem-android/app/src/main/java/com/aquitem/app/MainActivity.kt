package com.aquitem.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF166534)
private val LightGreen = Color(0xFFDCFCE7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AquiTemApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AquiTemApp() {
    var selected by remember { mutableStateOf("Início") }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Color(0xFF22C55E))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("AQUI TEM", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                            Text("Gestão do seu negócio", fontSize = 12.sp, color = Color.White.copy(alpha = .85f))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Green, titleContentColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Início", "Produtos", "Clientes", "Vendas").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = { Icon(when(item) { "Produtos" -> Icons.Default.Inventory2; "Clientes" -> Icons.Default.People; "Vendas" -> Icons.Default.PointOfSale; else -> Icons.Default.BarChart }, contentDescription = item) },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, indicatorColor = LightGreen)
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().background(Color(0xFFF7F9F7)).padding(padding),
                contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(if (selected == "Início") "Visão geral" else selected, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFF17251B))
                    Text("Bem-vindo ao AQUI TEM", color = Color(0xFF647067))
                }
                if (selected == "Início") {
                    item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        MetricCard("Receita hoje", "R$ 0,00", Modifier.weight(1f))
                        MetricCard("Produtos", "0", Modifier.weight(1f))
                    } }
                    item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        MetricCard("Vendas", "0", Modifier.weight(1f))
                        MetricCard("Estoque baixo", "0", Modifier.weight(1f))
                    } }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Comece por aqui", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("Esta é a primeira estrutura do aplicativo. Os dados ainda não são salvos; vamos implementar os cadastros e o banco local nas próximas etapas.", color = Color(0xFF647067), lineHeight = 20.sp)
                                Button(onClick = { selected = "Produtos" }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Inventory2, null); Spacer(Modifier.width(8.dp)); Text("Ir para produtos") }
                            }
                        }
                    }
                } else {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(when(selected) { "Produtos" -> "Cadastro de produtos"; "Clientes" -> "Cadastro de clientes"; else -> "Registro de vendas" }, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Text("Esta área está preparada para a próxima etapa de desenvolvimento.", color = Color(0xFF647067))
                                Text("Ainda não há dados cadastrados.", color = Green, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
                item { Text("Versão inicial 0.1.0 • modo demonstração", fontSize = 12.sp, color = Color(0xFF8A948D), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) }
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Color(0xFF647067), fontSize = 12.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Green)
        }
    }
}
